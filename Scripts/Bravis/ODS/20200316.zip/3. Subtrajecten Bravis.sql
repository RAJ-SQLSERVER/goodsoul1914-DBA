-- Subtrajecten Bravis
---------------------------------------------------------------------------------------------------

/*
R = Reguliere DBC (cijfercode 11). Een pati�nt met een nieuwe zorgvraag krijgt een eerste DBC geopend. 
	De typering hiervan is dus R, een reguliere DBC.
L = Langdurige zorg (cijfercode 21). De eerste DBC van de pati�nt is afgesloten en er wordt een vervolg DBC geopend.
I = Intercollegiaal consult (cijfercode 13). Als een pati�nt voor specialisme A is opgenomen en specialisme B 
	wordt in consult erbij gevraagd dan opent het tweede specialisme een DBC met zorgtype I. Ter info: als de pati�nt 
	uiteindelijk door specialisme B daadwerkelijk in behandeling wordt genomen wordt de DBC met zorgtype I (13) omgezet naar een zorgtype R (11).
*/

USE ODSProductie
GO

DECLARE @StartDatum			AS DATE			-- Startmoment
DECLARE @PeilDatum			AS DATE			-- Eindmoment / Peildatum
DECLARE @AGBCode			AS VARCHAR(8)	-- AGBCode
DECLARE @DetailOverzicht	AS BIT

SET @StartDatum =			'2017-01-01' 
SET @PeilDatum  =			'2020-02-29' 
SET @AGBCode    =			'06011036'		-- Bravis Ziekenhuis
SET @DetailOverzicht =		0				-- 0 = Toon gegroepeerde resulaten / 1 = Toon detailoverzicht

IF @DetailOverzicht = 0
	BEGIN
		SELECT GETDATE(), FORMAT (BEGINDAT, 'yyyy') as jaar, COUNT(*)
		FROM D001_EPISODE_DBCPER e						
		WHERE 
			e.VERVALLEN <> 1							-- die niet vervallen zijn
			AND e.BEGINDAT >= @StartDatum			
			AND e.BEGINDAT <= @PeilDatum				-- waarvan de begindatum tussen de @StartDatum en @EindDatum ligt
			AND e.LOCATIE IN (
				SELECT	CODE 
				FROM	D001_CSZISLIB_LOCCODE 
				WHERE	LOCCODE = @AGBCode
			)											-- die gelden voor Bravis Ziekenhuis
			AND e.STATUS <> 'X'							-- de status ongelijk is aan X
			AND e.EPISODE IN (
				SELECT	EPISODE 
				FROM	D001_EPISODE_EPISODE A, D001_PATIENT_PATIENT B 
				WHERE	A.PATIENTNR = B.PATIENTNR 
						AND B.IsTestPatient = 0)		-- die geen testpatienten betreffen
			AND e.STROOM <> 'R'							-- die niet REVALIDATIE betreffen
			AND e.DBCNUMMER IN (
				SELECT	CASENR 
				FROM	D001_FAKTUUR_VERRICHT_VERRSEC 
				WHERE	DATUM >= @StartDatum 
						AND DATUM <= @PeilDatum
			)											-- waarvan de faktuurdatum tussen @StartDatum en @EindDatum ligt
			AND e.ZORGTYPE IN ('L', 'R', 'I')			-- waarvan zorgtype is L, R of I
		GROUP BY FORMAT (e.BEGINDAT, 'yyyy')
		ORDER BY 2
	END
ELSE
	BEGIN
		SELECT	D.BEGINDAT,
				D.EINDDAT,
				D.DBCNUMMER,
				D.HOOFDDBC,
				D.EPISODE,
				D.SPECIALISM,
				D.ZORGTYPE,
				D.ZORGVRAAG,
				D.HOOFDDIAG,
				D.BEHCODE,
				D.INGBEH,
				D.LOCATIE,
				D.AFSLUIT,
				D.MEDIND,
				D.DECLCODE,
				D.ZORGPROD,
				D.VERWZORGPR,
				D.VERZEKERIN,
				D.DBCTypering,
				D.AFSLREG,
				D.ICD10,
				D.STATUS,
				D.VERVALLEN,
				D.STROOM
		INTO	Bravis_Subtrajecten_20160101_20191231
		FROM	D001_EPISODE_DBCPER D
		WHERE	VERVALLEN <> 1
				AND BEGINDAT >= @StartDatum
				AND BEGINDAT <= @PeilDatum
				AND LOCATIE IN (
					SELECT	CODE 
					FROM	D001_CSZISLIB_LOCCODE 
					WHERE	LOCCODE = @AGBCode
				)
				AND STATUS <> 'X'
				AND EPISODE IN (
					SELECT	EPISODE 
					FROM	D001_EPISODE_EPISODE A, D001_PATIENT_PATIENT B 
					WHERE	A.PATIENTNR = B.PATIENTNR AND B.IsTestPatient = 0
				)
				AND STROOM <> 'R'
				AND DBCNUMMER IN (
					SELECT	CASENR 
					FROM	D001_FAKTUUR_VERRICHT_VERRSEC 
					WHERE	DATUM >= @StartDatum 
							AND DATUM <= @PeilDatum
				)
				AND ZORGTYPE IN ('L', 'R', 'I')
		ORDER BY 1, 4
	END
GO
