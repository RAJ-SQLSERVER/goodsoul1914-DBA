/* 
   Subtrajecten ZorgBV 
*/

USE ODSProductie
GO

DECLARE @StartDatum			AS DATE			-- Startmoment
DECLARE @Peildatum			AS DATE			-- Eindmoment / Peildatum
DECLARE @AGBCode			AS VARCHAR(8)	-- AGBCode
DECLARE @DetailOverzicht	AS BIT

SET @StartDatum =			'2017-01-01'	
SET @Peildatum  =			'2020-02-29' 
SET @AGBCode    =			'22220339'		-- ZorgBV
SET @DetailOverzicht =		1				-- 0 = Toon gegroepeerde resulaten / 1 = Toon detailoverzicht

IF @DetailOverzicht = 0
	BEGIN
		SELECT	GETDATE(), FORMAT (BEGINDAT, 'yyyy') as jaar, COUNT(*)
		FROM	D001_EPISODE_DBCPER
		WHERE	VERVALLEN <> 1
				AND BEGINDAT >= @StartDatum
				AND BEGINDAT <= @Peildatum
				AND LOCATIE IN (
					SELECT	CODE 
					FROM	D001_CSZISLIB_LOCCODE 
					WHERE	LOCCODE = @AGBCode
				)
				AND STATUS <> 'X'
				AND EPISODE IN (
					SELECT	EPISODE 
					FROM	D001_EPISODE_EPISODE A, D001_PATIENT_PATIENT B 
					WHERE	A.PATIENTNR = B.PATIENTNR AND B.IsTestPatient = 0
				)
				AND STROOM <> 'R'
				AND DBCNUMMER IN (
					SELECT	CASENR 
					FROM	D001_FAKTUUR_VERRICHT_VERRSEC 
					WHERE	DATUM >= @StartDatum 
							AND DATUM <= @Peildatum
				)
				AND ZORGTYPE IN ('L', 'R', 'I')
		GROUP BY 
				FORMAT (BEGINDAT, 'yyyy')
		ORDER BY 2
	END
ELSE
	BEGIN
		SELECT	*
		FROM	D001_EPISODE_DBCPER
		WHERE	VERVALLEN <> 1
				AND BEGINDAT >= @StartDatum
				AND BEGINDAT <= @Peildatum
				AND LOCATIE IN (
					SELECT	CODE 
					FROM	D001_CSZISLIB_LOCCODE 
					WHERE	LOCCODE = @AGBCode
				)
				AND STATUS <> 'X'
				AND EPISODE IN (
					SELECT	EPISODE 
					FROM	D001_EPISODE_EPISODE A, D001_PATIENT_PATIENT B 
					WHERE	A.PATIENTNR = B.PATIENTNR 
							AND B.IsTestPatient = 0
				)
				AND STROOM <> 'R'
				AND DBCNUMMER IN (
					SELECT	CASENR 
					FROM	D001_FAKTUUR_VERRICHT_VERRSEC 
					WHERE	DATUM >= @StartDatum 
							AND DATUM <= @Peildatum
					)
				AND ZORGTYPE IN ('L', 'R', 'I')
		ORDER BY 1, 4
	END
GO

--BEGINDAT,
--				EINDDAT,
--				DBCNUMMER,
--				HOOFDDBC,
--				EPISODE,
--				SPECIALISM,
--				ZORGTYPE,
--				ZORGVRAAG,
--				HOOFDDIAG,
--				BEHCODE,
--				INGBEH,
--				LOCATIE,
--				AFSLUIT,
--				MEDIND,
--				DECLCODE,
--				ZORGPROD,
--				VERWZORGPR,
--				VERZEKERIN,
--				DBCTypering,
--				AFSLREG,
--				ICD10,
--				STATUS,
--				VERVALLEN,
--				STROOM