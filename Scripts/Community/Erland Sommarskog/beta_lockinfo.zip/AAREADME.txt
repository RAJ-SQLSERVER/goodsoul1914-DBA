This zip file includes four BAT files:

beta_lockinfo.bat         - For SQL 2016 and later.
beta_lockinfo_2012-14.bat - For SQL 2012 and SQL 2014.
beta_lockinfo_2008.bat    - For SQL 2008 and SQL 2008 R2.
beta_lockinfo_2005.bat    - For SQL 2005 (SP2 required).

The BAT files take four parameters:
%1 - Server instance. This parameter is manadatory.
%2 - Database where to load beta_lockinfo. Default is tempdb.
%3 - SQL Login to use. Default is to use Windows authentication.
%4 - Password for any SQL login.

Example:

C:\TEMP> beta_lockinfo myserver\thatinstance

All files load the corresponding version of beta_lockinfo, run it and 
saves data into the table guest.beta_lockfino. The BAT files use BCP
to copy the data to the file beta_lockinfo.bcp. Mail that file to
the person who gave you instructions to run beta_lockinfo. 

You should use the BAT file that matches your server instance. If you
get an error, first try DROP guest.beta_lockinfo, and beta_lockinfo
wiil recreate the table with the current version. If you still get
an error, run an earlier version. See also caveat below.

You can run the BAT file repeatedly, and all executions will be 
accumulated in the table, and thus the bcp file will include it all;
no need to send multiple files. Note, however, that the BAT files 
are set up to delete data older than 60 minutes from the table, so
if you are to run beta_lockinfo over a longer period before you 
send the data, change the value in BAT file.

Caveat: If you have the SQL 2005 tools installed in parallel with a 
later version, the folders for the SQL 2005 tools may appear in your
PATH before later versions. In this case BCP will give an error about 
the format file. Fix your PATH and run again. 

For a complete reference on beta_lockinfo, see 
http://www.sommarskog.se/sqlutil/beta_lockinfo.html